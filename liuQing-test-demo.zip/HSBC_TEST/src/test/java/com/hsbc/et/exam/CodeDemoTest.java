package com.hsbc.et.exam;

import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

/**
 * @author liu-qing
 * 2022-03-11 00：45：04
 */

public class CodeDemoTest {

    /**
     *
     * given:输入字符串aabcccbbad
     * when:执行CodeDemo.replace(str,true)
     * then: 通过输入的字符串判断是否有3个或3个以上的连续字符相同 相同则删除 直到字符串不连续为止。
     * 预期控制台输出
     * -> aabbbad
     * -> aaad
     * -> d
     * 预期值为 d
     */
    @Test
    public void test_replace_delete(){
        //given
        String str = "aabcccbbad";
        Map<String,Object> result = new HashMap<>();
        //when
        CodeDemo.replace(str,true,result);

        //Then
        Assert.assertEquals("d",result.get("result"));
    }


    /**
     *
     * given:输入字符串abcccbad
     * when:执行CodeDemo.replace(str,false)
     * then: 通过输入的字符串判断是否有3个或3个以上的连续字符相同 相同则替换上一个字母 直到字符串不连续为止。
     * 预期控制台输出
     * -> abbbad, ccc is replaced by b
     * -> aaad, bbb is replaced by a
     * -> d
     *预期值为 d
     */
    @Test
    public void test_replace_repetition(){
        //given
        String str = "abcccbad";
        Map<String,Object> result = new HashMap<>();
        //when
        CodeDemo.replace(str,false,result);

        //Then
        Assert.assertEquals("d",result.get("result"));
    }

}
