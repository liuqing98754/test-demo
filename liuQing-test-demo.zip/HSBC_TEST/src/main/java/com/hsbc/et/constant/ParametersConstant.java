package com.hsbc.et.constant;

public class ParametersConstant {

    /**
     *检测重复3次的数字或者字母的正则表达式
     * [a-zA-Z0-9] 表示出任意一个数字或者字母
     * ([a-zA-Z0-9]) 成为一个分组
     *  ([a-zA-Z0-9])\1{2} 把这个分组重复2次（加上原来的一共三次）
     */
    public static final String REG_TANDEM_DUPLICATION = "([a-zA-Z0-9])\\1{2}";

}
