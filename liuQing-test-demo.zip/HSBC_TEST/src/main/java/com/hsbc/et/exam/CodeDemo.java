package com.hsbc.et.exam;


import com.hsbc.et.constant.ParametersConstant;


import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;




/**
 * @author liu-qing
 * 2022-03-11 00:10:44
 */
public class CodeDemo {



    public static void main(String args[]) {
        String tesStr = "aabcccbbad";
        Map<String,Object> result = new HashMap<>();
        replace(tesStr, true,result);
        System.out.println(result.get("result"));
        tesStr = "abcccbad";
        replace(tesStr, false,result);
        System.out.println(result.get("result"));
    }

    /**
     * @param str      需要替换的字符串
     * @param isDelete ture 为通过输入的字符串判断是否有3个或3个以上的连续字符相同 相同则删除 直到字符串不连续为止。
     *                 false 则是不删除 改成替换上一个字母 若字母a替换为空串
     */
    public static void replace(String str, boolean isDelete, Map<String,Object> resultMap) {
        if (isDelete) {
              replaceDelete(str,resultMap);
        } else {
             replaceRepetition(str,resultMap);
        }
    }

    private static void replaceRepetition(String str, Map<String, Object> resultMap) {
        Matcher matcher = Pattern.compile(ParametersConstant.REG_TANDEM_DUPLICATION).matcher(str);
        if (matcher.find()) {
            //通过正则找出的连续字符串
            String group = matcher.group(0);
            char c = group.charAt(0);
            //需要替换的上一个字母
            String aChar = getChar(c);
            // char字符对应的ASCII码值 无需考虑其他非数字或字母的字符 上面正则已经筛选了
            str = str.replace(group, aChar);
            matcher = Pattern.compile(ParametersConstant.REG_TANDEM_DUPLICATION).matcher(str);
            if (matcher.find()){
                System.out.println(str + "，" + group + " is replaced by " + aChar);
                replaceRepetition(str, resultMap);
            }else {
                System.out.println(str);
                //递归结束 封装返回值
                resultMap.put("result",str);
                return;
            }
        }

    }

    private static void replaceDelete(String str, Map<String, Object> resultMap) {
        Matcher matcher = Pattern.compile(ParametersConstant.REG_TANDEM_DUPLICATION).matcher(str);
        if (matcher.find()) {
            str = str.replaceAll(ParametersConstant.REG_TANDEM_DUPLICATION, "");
            matcher = Pattern.compile(ParametersConstant.REG_TANDEM_DUPLICATION).matcher(str);
            if (matcher.find()) {
                System.out.println(str);
                replaceDelete(str, resultMap);
            }else {
                System.out.println(str);
                //递归结束 封装返回值
                resultMap.put("result",str);
                return;
            }
        }

    }

    /**
     * 通过输入的字母或数字返回上一个字母或数字，a或A 返回为空串
     *
     * @param c
     * @return
     */
    public static String getChar(char c) {
        if (c == 97 || c == 65) {
            return "";
        } else {
            c = (char) (c - 1);
            String Str = String.valueOf(c);
            return Str;
        }
    }
}
